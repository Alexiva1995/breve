@extends('layouts.admin')

@push('scripts')
    <script>
        $(window).on("load", function(){

            var datosServiciosNuevos = <?php echo json_encode($datosGraficoServiciosNuevos);?>;
            var datosServiciosAsignados = <?php echo json_encode($datosGraficoServiciosAsignados);?>;
            var datosServiciosCompletados = <?php echo json_encode($datosGraficoServiciosCompletados);?>;
            var datosServiciosCancelados = <?php echo json_encode($datosGraficoServiciosCancelados);?>;
            var ingresos = <?php echo json_encode($datosIngreso);?>;
            var ganancias = <?php echo json_encode($datosGanancia);?>;
            var horas = <?php echo json_encode($datosHora);?>;

            /*** Card Servicios Nuevos ***/
            var gainedChartoptions = {
                chart: {
                    height: 100,
                    type: 'area',
                    toolbar: {
                        show: false,
                    },
                    sparkline: {
                        enabled: true
                    },
                    grid: {
                        show: false,
                        padding: {
                            left: 0,
                            right: 0
                        }
                    },
                },
                colors: ['#11ec1a'],
                dataLabels: {
                    enabled: false
                },
                stroke: {
                    curve: 'smooth',
                    width: 2.5
                },
                fill: {
                    type: 'gradient',
                    gradient: {
                        shadeIntensity: 0.9,
                        opacityFrom: 0.7,
                        opacityTo: 0.5,
                        stops: [0, 80, 100]
                    }
                },
                series: [{
                    name: 'Servicios',
                    data: datosServiciosNuevos
                }],

                xaxis: {
                    labels: {
                        show: false,
                    },
                    axisBorder: {
                        show: false,
                    }
                },
                yaxis: [{
                    y: 0,
                    offsetX: 0,
                    offsetY: 0,
                    padding: { left: 0, right: 0 },
                }],
                tooltip: {
                    x: { show: false }
                },
            }

            var gainedChart = new ApexCharts(
                document.querySelector("#servicios-nuevos"),
                gainedChartoptions
            );

            gainedChart.render();

            /*** Card Servicios Asignados ***/
            var gainedChartoptions2 = {
                chart: {
                    height: 100,
                    type: 'area',
                    toolbar: {
                        show: false,
                    },
                    sparkline: {
                        enabled: true
                    },
                    grid: {
                        show: false,
                        padding: {
                            left: 0,
                            right: 0
                        }
                    },
                },
                colors: ['#1a5d1c'],
                dataLabels: {
                    enabled: false
                },
                stroke: {
                    curve: 'smooth',
                    width: 2.5
                },
                fill: {
                    type: 'gradient',
                    gradient: {
                        shadeIntensity: 0.9,
                        opacityFrom: 0.7,
                        opacityTo: 0.5,
                        stops: [0, 80, 100]
                    }
                },
                series: [{
                    name: 'Servicios',
                    data: datosServiciosAsignados
                }],

                xaxis: {
                    labels: {
                        show: false,
                    },
                    axisBorder: {
                        show: false,
                    }
                },
                yaxis: [{
                    y: 0,
                    offsetX: 0,
                    offsetY: 0,
                    padding: { left: 0, right: 0 },
                }],
                tooltip: {
                    x: { show: false }
                },
            }

            var gainedChart2 = new ApexCharts(
                document.querySelector("#servicios-asignados"),
                gainedChartoptions2
            );

            gainedChart2.render();

            /*** Card Servicios Completados ***/
            var gainedChartoptions3 = {
                chart: {
                    height: 100,
                    type: 'area',
                    toolbar: {
                        show: false,
                    },
                    sparkline: {
                        enabled: true
                    },
                    grid: {
                        show: false,
                        padding: {
                            left: 0,
                            right: 0
                        }
                    },
                },
                colors: ['#4caf50'],
                dataLabels: {
                    enabled: false
                },
                stroke: {
                    curve: 'smooth',
                    width: 2.5
                },
                fill: {
                    type: 'gradient',
                    gradient: {
                        shadeIntensity: 0.9,
                        opacityFrom: 0.7,
                        opacityTo: 0.5,
                        stops: [0, 80, 100]
                    }
                },
                series: [{
                    name: 'Servicios',
                    data: datosServiciosCompletados
                }],

                xaxis: {
                    labels: {
                        show: false,
                    },
                    axisBorder: {
                        show: false,
                    }
                },
                yaxis: [{
                    y: 0,
                    offsetX: 0,
                    offsetY: 0,
                    padding: { left: 0, right: 0 },
                }],
                tooltip: {
                    x: { show: false }
                },
            }

            var gainedChart3 = new ApexCharts(
                document.querySelector("#servicios-completados"),
                gainedChartoptions3
            );

            gainedChart3.render();

            /*** Card Servicios Asignados ***/
            var gainedChartoptions4 = {
                chart: {
                    height: 100,
                    type: 'area',
                    toolbar: {
                        show: false,
                    },
                    sparkline: {
                        enabled: true
                    },
                    grid: {
                        show: false,
                        padding: {
                            left: 0,
                            right: 0
                        }
                    },
                },
                colors: ['#EA5455'],
                dataLabels: {
                    enabled: false
                },
                stroke: {
                    curve: 'smooth',
                    width: 2.5
                },
                fill: {
                    type: 'gradient',
                    gradient: {
                        shadeIntensity: 0.9,
                        opacityFrom: 0.7,
                        opacityTo: 0.5,
                        stops: [0, 80, 100]
                    }
                },
                series: [{
                    name: 'Servicios',
                    data: datosServiciosCancelados
                }],

                xaxis: {
                    labels: {
                        show: false,
                    },
                    axisBorder: {
                        show: false,
                    }
                },
                yaxis: [{
                    y: 0,
                    offsetX: 0,
                    offsetY: 0,
                    padding: { left: 0, right: 0 },
                }],
                tooltip: {
                    x: { show: false }
                },
            }

            var gainedChart4 = new ApexCharts(
                document.querySelector("#servicios-cancelados"),
                gainedChartoptions4
            );

            gainedChart4.render();

            // Gráfico de Ingresos y Ganancias
            var lineAreaOptions = {
                chart: {
                    height: 350,
                    type: 'area',
                },
                colors: ['#1a5d1c', '#4caf50'],
                dataLabels: {
                    enabled: false
                },
                stroke: {
                  curve: 'smooth'
                },
                series: [{
                  name: 'Ingresos',
                  data: ingresos
                }, {
                  name: 'Ganancias',
                  data: ganancias
                }],
                legend: {
                  offsetY: -10
                },
                xaxis: {
                  type: 'datetime',
                  categories: horas,
                },
                yaxis: {
                  opposite: false
                },
                tooltip: {
                  x: {
                    format: 'dd/MM/yy HH:mm'
                  },
                }
            }
            var lineAreaChart = new ApexCharts(document.querySelector("#line-area-chart"), lineAreaOptions);
            lineAreaChart.render();
        });

        function asignarBrever($servicio){
            $('#service_id').val($servicio);
            $("#breverModal").modal('show');
        }
    </script>
@endpush
    
@section('content')
    <div class="row">
        <div class="col-lg-3 col-sm-6 col-12">
            <a href="{{ route('admin.services') }}">
                <div class="card">
                    <div class="card-header d-flex flex-column align-items-start pb-0">
                        <div class="avatar p-50 m-0" style="background-color: #11ec1a;">
                            <div class="avatar-content">
                                <i class="feather icon-user-plus font-medium-5"></i>
                            </div>
                        </div>
                        <h2 class="text-bold-700 mt-1 mb-25">{{ $cantServiciosNuevos }}</h2>
                        <p class="mb-0">Servicios Nuevos</p>
                    </div>
                    <div class="card-content">
                        <div id="servicios-nuevos"></div>
                    </div>
                </div>
            </a>
        </div>
        <div class="col-lg-3 col-sm-6 col-12">
            <a href="{{ route('admin.services.assigned') }}">
                <div class="card">
                    <div class="card-header d-flex flex-column align-items-start pb-0">
                        <div class="avatar p-50 m-0" style="background-color: #1a5d1c;">
                            <div class="avatar-content">
                                <i class="feather icon-user-minus font-medium-5"></i>
                            </div>
                        </div>
                        <h2 class="text-bold-700 mt-1 mb-25">{{ $cantServiciosAsignados }}</h2>
                        <p class="mb-0">Servicios Asignados</p>
                    </div>
                    <div class="card-content">
                        <div id="servicios-asignados"></div>
                    </div>
                </div>
            </a>
        </div> 
        <div class="col-lg-3 col-sm-6 col-12">
            <a href="{{ route('admin.services.completed') }}">
                <div class="card">
                    <div class="card-header d-flex flex-column align-items-start pb-0">
                        <div class="avatar p-50 m-0" style="background-color: #4caf50;">
                            <div class="avatar-content">
                                <i class="feather icon-user-check font-medium-5"></i>
                            </div>
                        </div>
                        <h2 class="text-bold-700 mt-1 mb-25">{{ $cantServiciosCompletados }}</h2>
                        <p class="mb-0">Servicios Completados</p>
                    </div>
                    <div class="card-content">
                        <div id="servicios-completados"></div>
                    </div>
                </div>
            </a>
        </div>
         <div class="col-lg-3 col-sm-6 col-12">
            <a href="{{ route('admin.services.canceled') }}">
                <div class="card">
                    <div class="card-header d-flex flex-column align-items-start pb-0">
                        <div class="avatar p-50 m-0" style="background-color: #EA5455;">
                            <div class="avatar-content">
                                <i class="feather icon-user-x font-medium-5"></i>
                            </div>
                        </div>
                        <h2 class="text-bold-700 mt-1 mb-25">{{ $cantServiciosCancelados }}</h2>
                        <p class="mb-0">Servicios Declinados</p>
                    </div>
                    <div class="card-content">
                        <div id="servicios-cancelados"></div>
                    </div>
                </div>
            </a>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-12 col-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="mb-0">Servicios Próximos</h4>
                </div>
                <div class="card-content">
                    <div class="table-responsive mt-1">
                        <table class="table table-hover-animation mb-0">
                            <thead>
                                <tr>
                                    <th>Fecha</th>
                                    <th>Hora</th>
                                    <th>Cliente</th>
                                    <th>Descripción</th>
                                    <th>Tarifa</th>
                                    <th>Acción</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($serviciosNuevos as $servicio)
                                    <tr>
                                        <td>{{ date('d-m-Y', strtotime($servicio->date)) }}</td>
                                        <td>{{ date('H:i', strtotime($servicio->time)) }}</td>
                                        <td>
                                            @if ($servicio->user_id == 0)
                                                {{ $servicio->client_name }} (No Registrado)
                                            @else
                                                @if (!is_null($servicio->user->tradename))
                                                    {{ $servicio->user->tradename}}
                                                @else
                                                    {{ $servicio->user->name }}
                                                @endif
                                            @endif
                                        </td>
                                        <td>{{ $servicio->sender_neighborhood }} - {{ $servicio->receiver_neighborhood }}</td>
                                        <td>${{ $servicio->rate + $servicio->additional_cost}}</td>
                                        <td>
                                            <div class="btn-group" role="group" aria-label="Basic example">
                                                <a type="button" class="btn btn-outline-info" href="{{ route('admin.services.show', $servicio->id) }}"><i class="fa fa-search"></i> Ver Detalles</a>
                                                <a type="button" class="btn btn-outline-primary" href="{{ route('services.show-route', $servicio->id) }}"><i class="fas fa-route"></i> Ver Ruta</a>
                                                <a type="button" class="btn btn-outline-success" href="javascript:;" onclick="asignarBrever({{$servicio->id}});"><i class="far fa-arrow-alt-circle-right"></i> Asignar Brever</a>
                                            </div>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th colspan="6" class="text-center"><a href="{{ route('admin.services') }}" class="text-success font-medium-2">Ver Más</a></th>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    @if (Auth::user()->financial == 1)
        <div class="row">
            <div class="col-lg-12 col-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Ingresos y Ganancias</h4>
                    </div>
                    <div class="card-content">
                        <div class="card-body">
                            <div id="line-area-chart"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    @endif

     {{-- Modal para Asignar un Brever a un Servicio --}}
    <div class="modal fade text-left" id="breverModal" tabindex="-1" role="dialog" style="display: none;" aria-hidden="true">
        <div class="modal-dialog modal-dialog-scrollable modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="myModalLabel1">Asignar Breve</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <form action="{{ route('admin.services.add-brever') }}" method="POST">
                    @csrf
                    <input type="hidden" name="service_id" id="service_id">
                    <div class="modal-body">
                        <div class="form-group">
                            <label>Seleccione el brever a asignar</label>
                            <div class="form-group">
                                <select class="select2 form-control" name="brever_id">
                                    @foreach ($breves as $breve)
                                        <option value="{{ $breve->id }}">{{ $breve->name }}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary waves-effect waves-light">Asignar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection